package com.company.mungdaum.coupon;

public class CouponDAO {

}
