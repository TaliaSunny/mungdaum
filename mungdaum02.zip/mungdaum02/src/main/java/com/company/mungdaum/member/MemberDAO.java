package com.company.mungdaum.member;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.company.mungdaum.common.JDBCUtil;
import com.company.mungdaum.common.PasswordEncryptUtil;

public class MemberDAO {
	private Connection conn = null;
	private PreparedStatement pstmt = null;
	private ResultSet rs = null;
	
	String pwEncrypt = null; //전역 참조 변수(어디든 끌어다 쓸 수 있다.)
	
	private final String USER_GET 
		= "select * from member where MId=? AND MPw=?";
	
	public MemberVO getMember(MemberVO memberVO) {
		MemberVO member = null;			
		
		try {
			System.out.println("===> getMember() 메소드 처리됨.");
			
			conn = JDBCUtil.getConnection();
			pstmt = conn.prepareStatement(USER_GET);
			pstmt.setString(1, memberVO.getMId());
			pstmt.setString(2, memberVO.getMPw());
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				member = new MemberVO();
				member.setMId(rs.getString("ID"));
				member.setMPw(rs.getString("PASSWORD"));
				member.setMName(rs.getString("NAME"));
		    	//user.setRole(rs.getString("Role"));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			JDBCUtil.close(rs, pstmt, conn);
		}
		return member;
	}//end getUser()=================================================================

	//회원가입 데이터 등록 메소드 구현
	public void insertMember(MemberVO memberVO) {
		System.out.println("===> insertUser() 메소드 처리 완료");
		
		String MEMBER_INSERT = "insert into member values(?,?,?,?,?)";
		
		try {
			conn = JDBCUtil.getConnection();
			pstmt = conn.prepareStatement(MEMBER_INSERT);
			pstmt.setString(1, memberVO.getMId());
			pstmt.setString(2, memberVO.getMPw());
			
			//입력 받은 패스워드를 암호화 시켜 세 번째 물음표 값으로 지정하자!!
			String plainText = memberVO.getMPw();
			pwEncrypt = PasswordEncryptUtil.encryptSHA256(plainText);
			pstmt.setString(3, pwEncrypt);
			//위 세줄은 중요!
			pstmt.setString(4, memberVO.getMName());
			//pstmt.setString(5, memberVO.getRole());
			pstmt.executeUpdate();
			
		}catch(Exception e){
			e.printStackTrace();
		}finally {
			JDBCUtil.close(pstmt, conn);
		}
		
	}
}
