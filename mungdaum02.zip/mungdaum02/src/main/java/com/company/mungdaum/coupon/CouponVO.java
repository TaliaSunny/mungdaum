package com.company.mungdaum.coupon;

public class CouponVO {

}
