package com.company.mungdaum.qna;

public class QnaVO {

}
