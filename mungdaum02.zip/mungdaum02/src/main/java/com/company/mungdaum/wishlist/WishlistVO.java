package com.company.mungdaum.wishlist;

public class WishlistVO {

}
