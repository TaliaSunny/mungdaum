package com.company.mungdaum.admin;

public class AdminVO {

}
