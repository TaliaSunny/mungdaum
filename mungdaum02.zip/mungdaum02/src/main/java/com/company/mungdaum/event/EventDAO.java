package com.company.mungdaum.event;

public class EventDAO {

}
