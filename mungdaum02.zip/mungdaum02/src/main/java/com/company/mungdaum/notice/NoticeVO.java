package com.company.mungdaum.notice;

public class NoticeVO {

}
