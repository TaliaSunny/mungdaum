package com.company.mungdaum.freecomunity;

public class FreeCommunityDAO {

}
