package com.company.mungdaum.product;

public class ProductDAO {

}
