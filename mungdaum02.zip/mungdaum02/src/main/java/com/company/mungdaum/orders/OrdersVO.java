package com.company.mungdaum.orders;

public class OrdersVO {

}
