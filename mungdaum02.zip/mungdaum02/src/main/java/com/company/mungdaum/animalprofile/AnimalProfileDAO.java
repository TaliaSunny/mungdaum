package com.company.mungdaum.animalprofile;

public class AnimalProfileDAO {

}
