package com.company.mungdaum.comment;

public class CommentDAO {

}
