package com.company.mungdaum.wishlist;

public class WishlistDAO {

}
