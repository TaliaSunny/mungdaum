package com.company.mungdaum.admin;

public class AdminDAO {

}
