package com.company.mungdaum.review;

public class ReviewVO {

}
