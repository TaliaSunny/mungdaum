package com.company.view.qna;

public class QnaController {

}
