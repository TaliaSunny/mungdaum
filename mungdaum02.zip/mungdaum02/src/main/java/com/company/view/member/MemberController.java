package com.company.view.member;

public class MemberController {

}
