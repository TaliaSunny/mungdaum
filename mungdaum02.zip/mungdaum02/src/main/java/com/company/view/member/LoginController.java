package com.company.view.member;

public class LoginController {

}
