package com.company.view.member;

public class LogoutController {

}
