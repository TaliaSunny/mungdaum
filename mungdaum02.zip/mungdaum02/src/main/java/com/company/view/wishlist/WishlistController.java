package com.company.view.wishlist;

public class WishlistController {

}
