package com.company.view.notice;

public class NoticeController {

}
