package com.company.view.user;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.company.mungdaum.member.MemberDAO;
import com.company.mungdaum.member.MemberVO;

@Controller
public class MemberController {
	
	@RequestMapping("/insertUser.do")
	public String insertMember(MemberVO memberVO, MemberDAO memberDAO) {
		//기본  개발 방법에서 코딩한 10줄이 생략된다.
		memberDAO.insertMember(memberVO);
		return "index.jsp";
	}
	
}
