package com.company.view.comment;

public class CommentController {

}
