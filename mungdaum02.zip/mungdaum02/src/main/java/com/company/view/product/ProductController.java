package com.company.view.product;

public class ProductController {

}
