package com.company.view.event;

public class EventController {

}
