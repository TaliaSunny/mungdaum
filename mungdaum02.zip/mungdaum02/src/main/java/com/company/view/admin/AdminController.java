package com.company.view.admin;

public class AdminController {

}
