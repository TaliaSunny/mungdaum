package com.company.view.user;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.company.mungdaum.member.MemberDAO;
import com.company.mungdaum.member.MemberVO;

@Controller
public class LoginController { // << 어떠한 인퍼페이스도 임플리먼트, 클래스도 상속을 받지 않는 클래스를 POJO 클래스라 한다. 
	
	@RequestMapping("/login.do")												
	
	public String login(MemberVO memberVO, MemberDAO memberDAO, HttpSession session) {	
		
		
		MemberVO member = memberDAO.getMember(memberVO);// getUser(userDO) 만들어 주러 가자. 이미 userDO에는 폼에서 넘어온 값들이 다 저장되어 있다.
		
		if(member != null) {	// 로그인 인증 성공
			System.out.println("로그인 인증 성공!!");
			session.setAttribute("userName", member.getMName());
			
			return "index.jsp";      
		}else { //로그인 인증 실패
			return "index.jsp";
		}
	}
}