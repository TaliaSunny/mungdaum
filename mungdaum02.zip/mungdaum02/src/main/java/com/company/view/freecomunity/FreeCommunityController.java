package com.company.view.freecomunity;

public class FreeCommunityController {

}
